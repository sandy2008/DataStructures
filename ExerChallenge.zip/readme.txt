================================
An example answer of Challenging Exersice
================================
Compiling:				
$ gcc -o sorting sort_driver2.c sort_rec.c


Usage: 
$ ./sorting len sw opt

The option opt specifies a sorting method
- Bubblesort if opt = 0
- Insetion sort if opt = 1
- Selection sort if opt = 2

Execution:   
$ ./sorting 5 0 0 	(sort a random array by bubble sort)
$ ./sorting 5 1 1	(sort an user's input array by insertion sort)
$ ./sorting 5 2 2	(sort an already sorted array by selection sort)


Each sorting function is defined as a recursive program. 
