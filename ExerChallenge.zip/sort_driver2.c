#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "sort.h"

int c;

void mes(char * prog){
    printf("Usage : %s len sw opt\n\n", prog);
    printf("It generates an array of length len and sort it. \n");
    printf("The array : \n");
    printf("- random array (sw = 0)\n");
    printf("- user's input array (sw = 1)\n");
    printf("- already sorted array (sw = 2)\n");
    printf("\n");
    printf("The sorting method : \n");
    printf("- bubble sort (opt = 0)\n");
    printf("- insertion sort (opt = 1)\n");
    printf("- selection sort (opt = 2)\n");
    printf("\n");
    printf("Example : %s 10 0 0\n");
    printf("It generates a random array of length 10 and sort it by bubble sort\n", prog);
    return;
}


void main(int argc, char *argv[]){ 
  char* prog = argv[0];
  if (argc != 4){
    mes(prog);
    return;
  }

  int i = 0;
  int N = atoi(argv[1]);
  int sw = atoi(argv[2]);
  int opt = atoi(argv[3]);
  int *a = malloc(N*sizeof(int));
  clock_t start, end;

  switch(opt){
  case 0:
    printf("[Bubble sort]\n");
    break;
  case 1:
    printf("[Insertion sort]\n");
    break;
  case 2:
    printf("[Selection sort]\n");
    break;
  default:
    mes(prog);
    return;
  }

  srand(1);
  switch(sw){
  case 0: 
    for (i = 0; i < N; i++) 
      a[i] = 1000*(1.0*rand()/RAND_MAX);
    break;
  case 1:
    for (i = 0; i<N; i++) scanf("%d", &a[i]);
    break;
  default:
    for (i = 0; i < N; i++) a[i] = i;
    break;
  }

  c = 0;

  start = clock();
  sort(a, 0, N-1, opt);
  end = clock();

  for (i = 0; i < N; i++) printf("%3d ", a[i]);

  printf("\n");
  printf("counter = %d\n", c);
  printf("cpu time=%10.6f[sec]\n",(double)(end-start)/CLOCKS_PER_SEC);
}
