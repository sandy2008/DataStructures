#include<stdio.h>
#include "sort.h"
extern int c;

void arrayPrint(Item a[], int len){
  int i;
  for(i = 0; i < len; i++) printf("%d ", a[i]);
    printf("\n");
}

/* bubble sort */
void bubble(Item a[], int left, int cur){
  if(left == cur) return;
  compexch(a[cur-1],a[cur]);
  c++;
  bubble(a,left,cur-1);
}

void bubblesortRec(Item a[], int left, int right){
  if(left == right) return;
  bubble(a,left,right);
  bubblesortRec(a,left+1,right);
}

/* insertion sort */
void insertion(Item a[], int left, int cur){
  if(left == cur) return;
  if (++c && less(a[cur],a[cur-1])){ 
      exch(a[cur-1],a[cur]);
      insertion(a,left,cur-1);
    }
    return;
  }

void isortRec(Item a[], int left, int cur, int right){
  if(cur > right) return;
  insertion(a,left,cur);
  isortRec(a,left,cur+1,right);
}

void insertsortRec(Item a[], int left, int right){
  isortRec(a, left, left, right);
}

/* selection sort */
int findSmallest(Item a[], int left, int right){
  if(left == right) return left;
  int rmin = findSmallest(a, left+1,right);
  if(++c && a[left] <= a[rmin]) return left;
  else return rmin;
}
void selectionsortRec(Item a[], int left, int right){
  if(left == right) return;
  int min = findSmallest(a,left,right);
  exch(a[left],a[min]);
  selectionsortRec(a,left+1,right);
}

/* body */
void sort(Item a[], int left, int right, int opt){
  switch(opt){
  case 0: 
    bubblesortRec(a,left,right);
    break;
  case 1:
    insertsortRec(a,left,right);
    break;
  case 2:
    selectionsortRec(a,left,right);
    break;
  default:
    break;
  }
}
